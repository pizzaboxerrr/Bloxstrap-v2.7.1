﻿namespace Bloxstrap.Models.RobloxApi
{
    // lmao its just one property
    public class UniverseIdResponse
    {
        [JsonPropertyName("universeId")]
        public long UniverseId { get; set; }
    }
}
