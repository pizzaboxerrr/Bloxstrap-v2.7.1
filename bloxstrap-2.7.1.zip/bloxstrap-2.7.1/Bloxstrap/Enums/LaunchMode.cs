﻿namespace Bloxstrap.Enums
{
    public enum LaunchMode
    {
        Player,
        Studio,
        StudioAuth
    }
}
