﻿namespace Bloxstrap.Enums
{
    public enum ServerType
    {
        Public,
        Private,
        Reserved
    }
}
