﻿namespace Bloxstrap.Enums
{
    public enum CursorType
    {
        [EnumName(FromTranslation = "Common.Default")]
        Default,
        From2006,
        From2013
    }
}
